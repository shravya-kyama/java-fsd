package assisted_prj;

public class Student {
	
	
	    private String name;
	    private int age;

	    
	    public Student() {
	        this.name = "";
	        this.age = 0;
	    }

	    
	    public Student(String name, int age) {
	        this.name = name;
	        this.age = age;
	    }

	    
	    public Student(Student otherStudent) {
	        this.name = otherStudent.name;
	        this.age = otherStudent.age;
	    }

	    
	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }

	    
	    public void setName(String name) {
	        this.name = name;
	    }

	    public void setAge(int age) {
	        this.age = age;
	    }

	    public void printDetails() {
	        System.out.println("Name: " + name);
	        System.out.println("Age: " + age);
	    }

	    public static void main(String[] args) {
	       
	        Student student1 = new Student();
	        student1.printDetails();

	        
	        Student student2 = new Student("pranathi", 22);
	        student2.printDetails();

	        
	        Student student3 = new Student(student2);
	        student3.printDetails();

	        
	        student1.setName("preethi");
	        student1.setAge(25);
	        student1.printDetails();
	    }
	}


