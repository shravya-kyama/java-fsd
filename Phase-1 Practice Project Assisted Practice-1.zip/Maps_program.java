package assisted_prj;

import java.util.*;

public class Maps_program {


	    public static void main(String[] args) {
	        
	        Map<String, Integer> map = new HashMap<>();

	       
	        map.put("chocolate", 1);
	        map.put("icecream", 2);
	        map.put("biscuit", 3);

	        
	        int chocolateValue = map.get("chocolate");
	        System.out.println("The value of the 'chocolate' key is: " + chocolateValue);

	      
	        boolean containsicecream = map.containsKey("icecream");
	        System.out.println("The map contains the 'icecream' key: " + containsicecream);

	        
	        map.remove("biscuit");

	        //  the remaining key values in the map
	        System.out.println("The remaining key values in the map are:");
	        for (Map.Entry<String, Integer> entry : map.entrySet()) {
	            String key = entry.getKey();
	            int value = entry.getValue();
	            System.out.println(key + " = " + value);
	        }
	    }
	}



