package assisted_prj;

public class AccessModifier {
	

	    public static void main(String[] args) {
	        Person person = new Person();

	        
	        person.name = "John";
	        person.age = 30;
	        System.out.println("Name: " + person.name);
	        System.out.println("Age: " + person.age);

	        
	        person.sayHello();

	       
	        Employee employee = new Employee();
	        employee.name = "Sarah";
	        employee.age = 25;
	        employee.salary = 50000;
	        System.out.println("Name: " + employee.name);
	        System.out.println("Age: " + employee.age);
	        System.out.println("Salary: " + employee.salary);

	      
	        employee.displaySalary();
	    }
	}

	class Person {
	    public String name;
	    public int age;
	    private String gender;

	    public void sayHello() {
	        System.out.println("Hello!");
	    }

	    private void displayGender() {
	        System.out.println("Gender: " + gender);
	    }
	}

	class Employee extends Person {
	    protected int salary;

	    protected void displaySalary() {
	        System.out.println("Salary: " + salary);
	    }
	}



