package assisted_prj;

import java.util.regex.*;

public class RegexVerifier {
    public static void main(String[] args) {
       
        String regex = "1*2";
        
      
        String[] inputs = {
            "2",
            "12",
            "112",
            "1112",
            "11112"
             };
        
    
        Pattern pattern = Pattern.compile(regex);
        
       
        for (String input : inputs) {
            Matcher matcher = pattern.matcher(input);
            boolean matches = matcher.matches();
            System.out.printf("Input: %s, Matches: %b%n", input, matches);
        }
    }
}

