package assisted_prj;

public class TypeCastingExample {
	
	 public static void main(String[] args) {
	        // declaring and initializing the variable
	        int i = 58;
	        long l = i;
	        float f = l;
	        double d = f;
	        
	        System.out.println("Implicit type casting (widening):");
	        System.out.println("int value: " + i);
	        System.out.println("long value: " + l);
	        System.out.println("float value: " + f);
	        System.out.println("double value: " + d);

	        // declaring and initializing the variable
	        double d2 = 1234.56;
	        float f2 = (float) d2;
	        long l2 = (long) f2;
	        int i2 = (int) l2;

	        System.out.println("Explicit type casting (narrowing):");
	        System.out.println("double value: " + d2);
	        System.out.println("float value: " + f2);
	        System.out.println("long value: " + l2);
	        System.out.println("int value: " + i2);
	    }
	}


