package assisted_prj;

public class stringconversion {
	
	public static void main(String[] args) {
        String str = "Hello, world!";
        System.out.println("Original string: " + str);

        // Convert String to StringBuffer
        StringBuffer strBuffer = new StringBuffer(str);
        System.out.println("String converted to StringBuffer: " + strBuffer);

        // Convert String to StringBuilder
        StringBuilder strBuilder = new StringBuilder(str);
        System.out.println("String converted to StringBuilder: " + strBuilder);
    }


}
