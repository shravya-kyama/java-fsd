package assisted_prj;

import java.util.*;

public class Collection {
	
	   public static void main(String[] args) {
	        
	        List<Integer> list = new LinkedList<>();
	        list.add(30);
	        list.add(50);
	        list.add(80);
	        System.out.println("LinkedList: " + list);

	        
	        Set<String> set = new TreeSet<>();
	        set.add("pen");
	        set.add("pencil");
	        set.add("box");
	        System.out.println("TreeSet: " + set);

	        
	        Map<String, Integer> map = new HashMap<>();
	        map.put("pen", 1);
	        map.put("pencil", 2);
	        map.put("box", 3);
	        System.out.println("HashMap: " + map);

	        
	        System.out.print("LinkedList elements: ");
	        for (int element : list) {
	            System.out.print(element + " ");
	        }
	        System.out.println();

	        
	        System.out.print("TreeSet elements: ");
	        for (String element : set) {
	            System.out.print(element + " ");
	        }
	        System.out.println();

	        
	        System.out.print("HashMap elements: ");
	        for (Map.Entry<String, Integer> entry : map.entrySet()) {
	            System.out.print(entry.getKey() + "=" + entry.getValue() + " ");
	        }
	        System.out.println();
	    }


}
