package assisted_prj;

import java.util.Arrays;

public class Method {

    public static void main(String[] args) {
        // Calling a static method
        int result1 = add(2, 3);
        System.out.println("Result 1: " + result1);

        // Calling an instance method on an object
        Calculator calculator = new Calculator();
        int result2 = calculator.subtract(5, 2);
        System.out.println("Result 2: " + result2);

        // Calling a method
        int[] numbers = {1, 2, 3};
        incrementArray(numbers);
        System.out.println("Numbers after increment: " + Arrays.toString(numbers));

        
        int x = 10;
        int y = 5;
        swap(x, y);
        System.out.println("x: " + x);
        System.out.println("y: " + y);
    }

    public static int add(int a, int b) {
        return a + b;
    }

    public static void swap(int a, int b) {
        int temp = a;
        a = b;
        b = temp;
    }

    public static void incrementArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            arr[i]++;
        }
    }
}

class Calculator {
    public int subtract(int a, int b) {
        return a - b;
    }
}


